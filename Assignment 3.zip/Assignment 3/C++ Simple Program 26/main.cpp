
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 7:31 PM
 * Purpose : Use case statement for a message based on users answer
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    int FirstChoice = 1;
    switch (FirstChoice + 1)//make a message based on answer
    {
     case 1:
    cout << "Roast beef\n";
    break;
    case 2:
     cout << "Roast worms\n";
     break;
     case 3:
    cout << "Chocolate ice cream\n";
    case 4:
    cout << "Onion ice cream\n";
    break;
    default:
     cout << "Bon appetit!\n";
    }
    //END
  return 0;
} 

