
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 7:01 PM
 * Purpose : Find median number
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    int num1 = 2;
    int num2 = 3;
    float x = (2+ 3) /2;//calculate the median of the number
    cout<<"The number between 2 and 3 is "<<x<<endl;//write message
    //END
  return 0;
} 

