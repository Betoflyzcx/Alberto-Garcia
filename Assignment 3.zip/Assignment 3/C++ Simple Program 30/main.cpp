
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 9:59 PM
 * Purpose : Display number in the power of two
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    int n = 1024;
    int log = 0;
    for (int i = 1; i < n; i = i * 2)//use i for the power of two
        log++;
        cout << n << " " << log << endl;//write n and log
    //END
  return 0;
} 

