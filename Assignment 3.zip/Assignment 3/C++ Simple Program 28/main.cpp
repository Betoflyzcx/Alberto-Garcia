
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 9:42 PM
 * Purpose : Make a timer count up
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    int n = 1;
    do//add 1 to n until its 4
    cout << n << " ";//write n
    while (n++ <= 3);
    //END
  return 0;
} 

