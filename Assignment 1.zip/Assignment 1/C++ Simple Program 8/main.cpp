/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 3, 2016, 01:30 PM
 * Purpose : Ouput String With Value Of, "The answer to the question of Life,. . ." 
 */

//System Libraries
#include <iostream>//Input/Output Library
using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv)
{
    // Declare Variables 
    string message = "The answer to the question of Life, the Universe, and Everything is 42."; // Sets Value To String
    
    //Output "message"
    cout<<message<<endl;
    
    // Exit Stage Right!
    return 0;
}