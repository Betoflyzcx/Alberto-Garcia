/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 3, 2016, 01:25 PM
  * Purpose : Output Uninitialized Variables
 */

//System Libraries
#include <iostream>//Input/Output Library
using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv)
{
    // Declare Variables
    int num1;
    int num2;
    int num3;
    int num4;
    int num5;
    int num6;
    int num7;
    
    // Output Variables
    cout<<num1<<endl;
    cout<<num2<<endl;
    cout<<num3<<endl;
    cout<<num4<<endl;
    cout<<num5<<endl;
    cout<<num6<<endl;
    cout<<num7<<endl;
    
    // Exit Stage Right! 
    return 0;
}

