
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 3, 2016, 1:15 PM
 * Purpose : Add A Constant Value To A Number Consecutively
 */

//System Libraries
#include <iostream>//Input/Output Library
using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv)
{
    // Declare Variables
    float length = 8.3; // Default Length
    int answer;
    
    // Output Tells user whether they wish to continue or not
    cout<<"Enter 1 to increase length value or Enter 0 to exit:  Length ="<<length<<endl;
    
    // Input User Answer
    cin >> answer;
    
    while(true) // Loops Until User Says No
    {
    switch(answer)
    {
            case 0:return 0;break; // Ends Program
            
            case 1: // Increases Length
                
                // Output Tells user whether they wish to continue or not / Displays length
                cout<<"Enter 1 to increase length value or Enter 0 to exit Length ="<<length<<endl;
                
                // Input Whether Or Not To Continue
                cin >> answer;
                
                length += 4.5; // If Continues Moves On To This Line
                break;
                
                
                // If Anything Else than 0 or 1 are Input
            default: 
            
            //Output Error!
            cout<<endl<<"ERRROR: You Cannot exceed the value of 1"<<endl<<endl;
            
            // Output Solution!
            cout<<"Enter 1 to increase length value or Enter 0 to exit Length ="<<length<<endl;
            
            // Input Solution
            cin >> answer;
                
     }
    }
   
    // Program Ends in Case 0;
}

