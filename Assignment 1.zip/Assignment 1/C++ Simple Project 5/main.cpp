
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 3, 2016, 1:23 PM
 * Purpose : To add two numbers
 */

//System Libraries
#include <iostream>//Input/Output Library
using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes


//Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare variables 
    int n1 = 0; 
    int n2 = 0;
    int sum = n1 + n2;//the sum of num1 and num2
    
    
    //Exit Stage Right!
    return 0;
}
