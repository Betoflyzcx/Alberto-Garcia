
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 3, 2016, 01:36 PM
 * Purpose : Make a number Add by one whenever 1 is entered && Dislay "High" When Value is 100 or more
 */

// System Libraries
#include <iostream> // Input/Output Library

//User Libraries



//Global Constants



//Function Prototypes


using namespace std; //Namespace of the System Libraries


// Execution Begins Here!
int main(int argc, char** argv)
{
  //Declare Variables
  int score = 0;
  int Add =0;
  
 
  while(true){   // Loops infinitely
  
  // Output
   cout <<endl << "Input 1 To Add 1 To Score"<< endl;
   
   // Input Whether Or Not To Add 1 
   cin >> Add;
  
  //Adds 1 To Score 
   if (Add == 1)
   {
    score +=1;
   }
   
   //Output High when score >= 100
   if (score > 100)
   {
    cout << endl << "High";   
   }
   
   
   // Outputs low when score < 100
   else 
   {
    cout << endl << "Low";
   }
   
  }
  
  // Exit Stage Right
  return 0;
}
