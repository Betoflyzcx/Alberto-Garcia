
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 08:58 AM
 * Purpose : Make a Program Decide Whether The Grades Passing Or Not
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
  //Declare Variables
   int Exam; 
   int programs_done;
   
   //Output
   cout << "Enter Exam Score" << endl;
   
   // Input Value Of Exam 
   cin >> Exam;
   
   // Output
   cout << "Now Enter Amount Of Programs Done Score" << endl;
           
           
   // Input Value Of programs_done
   cin >> programs_done;
   
   // Decides Whether Or Not To Display Passed
   if (Exam + programs_done >= 70)
   {
    // Output Passed
    cout << "Passed! (:" << "\n" << endl;
   }
   
	// //Decides Whether Or Not To Display Failed
    else if(Exam + programs_done < 70)
   {
	//Output Failed
	 cout << "Failed!! :(" << "\n" << endl;
   }
   
  // Exit Stage Right!
  return 0;
} 

