
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 5:21 PM
 * Purpose : Use tabs o make columns
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    float num1 = 1.000;
    float num2 = 1.414;
    float num3 = 1.732;
    float num4 = 2.000;
    float num5 = 2.236;
    //Write Columns of number
    cout<<"N\t Square root"<<endl;
    cout<<"1\t"<<num1<<endl;
    cout<<"2\t"<<num2<<endl;
    cout<<"3\t"<<num3<<endl;
    cout<<"4\t"<<num4<<endl;
    cout<<"5\t"<<num5<<endl;
  return 0;
} 

