
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 4:34 PM
 * Purpose : Simple adding calculator
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    int num1;
    int num2;
    int total = num1 + num2;
    cout<<"This is a adding calculator"<<endl;//Greet user
    cout<<"Please Enter your first number"<<endl;//Ask user for first number
    cin>>num1;//Read first number
    cout<<"Please enter you second number"<<endl;//ask user for second number
    cin>>num2;//Read second number
    cout<<num1<< " + "<<num2<<" = "<<total<<endl;//Output the sum of both numbers
    //END
  return 0;
} 

