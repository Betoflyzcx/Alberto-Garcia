
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 5:32 PM
 * Purpose : Convert equations to c++
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables 
    int x = 3;
    int y = 5;
    int z = 19;
    3*x;//3x
    3*x+y;//3x+y
    x+y/7;
    3*x+y/z+2;//3x+y/z+2
    //End
  return 0;
} 

