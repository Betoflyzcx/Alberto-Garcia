
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 5:32 PM
 * Purpose : Display equation in word format
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables 
    int number = (1/3) * 3;
    cout << "(1/3) * 3 is equal to " << number;//display math problem
//End
  return 0;
} 



