
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 4:34 PM
 * Purpose : Simple adding calculator
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    cout<< "\tThis sentence is indented!"<<endl<<"The program is now ending"<<endl//Output indented message
    //END
  return 0;
} 

