
/* 
 * File:   main.cpp
 * Author: Alberto Garcia
 * Created on July 4, 2016, 6:02 PM
 * Purpose : Convert celsius to fehrenheit
 */

// System Libraries
#include <iostream> // Input/Output Library

using namespace std; //Namespace of the System Libraries


//User Libraries



//Global Constants



//Function Prototypes



// Execution Begins Here!
int main(int argc, char** argv)
{
    //Declare Variables
    string month = "03";
    string day = "04";
    string year = "06";
    string date = month + day + year;
    cout << date << endl;
//End
  return 0;
} 



